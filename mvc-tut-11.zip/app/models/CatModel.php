<?php 

class CatModel extends Dmodel{


	public function __construct(){
		parent::__construct();
	}

	public function catlist($table){
		return $this->db->select($table);
	} 
	public function catbyid($table, $id){
		$sql = "SELECT * FROM $table WHERE id=:id";
		$stmt = $this->db->prepare($sql);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		return $stmt->fetchAll();
	} 


}