<?php 

class Database extends PDO{

	
	public function __construct(){
		$dsn = "mysql:host=localhost;dbname=mvc";
		$username = "root";
		$password = ""; 
		parent::__construct($dsn,$username,$password);
	}
  

}