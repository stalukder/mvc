<?php 

class Index extends DController{
	public function __construct(){
		parent:: __construct();
	}

	public function home(){
		$this->load->view('home');  
	}
	public function category(){ 
		$table = "category";
		$data = array();
		$catmodel = $this->load->model('CatModel');
		$data['cat'] = $catmodel->catlist($table);  
		$this->load->view('category',$data); 
	}
	public function catById(){ 
		$table = "category";
		$id = 2;
		$data = array();
		$catmodel = $this->load->model('CatModel');
		$data['catbyid'] = $catmodel->catbyid($table, $id);  
		$this->load->view('catbyid',$data); 
	}
}