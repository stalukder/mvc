<?php 

class Dmodel{
	protected $db = array();
	public function __construct(){
		 $this->db = new Database();
	}

 

}