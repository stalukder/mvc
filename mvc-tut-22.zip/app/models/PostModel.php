<?php 

class PostModel extends Dmodel{


	public function __construct(){
		parent::__construct();
	}

	public function allPost($table){
		$sql = "SELECT * FROM $table ORDER BY ID DESC LIMIT 3 ";
		return $this->db->select($sql);
	}  
	
	public function postById($table,$cat,$id){
		$sql = "SELECT $table.*,$cat.catName FROM $table
				INNER JOIN $cat
				ON $table.cat = $cat.id
				WHERE $table.id = $id ";
		return $this->db->select($sql);
	}
	public function getpostByCat($table,$cat,$id){
		
	}
}