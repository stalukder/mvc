<?php 

class Index extends DController{
	public function __construct(){
		parent:: __construct();
	}

	public function home(){
		echo "home"; 
	}
}