<?php 

class Load{
	public function __construct(){
		
	}
}