<?php 

class Bpl extends DController{
	function __construct(){
		echo "From Bpl Controler";
	}
}