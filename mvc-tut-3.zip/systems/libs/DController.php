<?php 

class DController{
	function __construct(){
		echo "from Parent DController";
	}
}