<?php 
include "inc/header.php"; 
include "systems/libs/DController.php"; 




$url = $_GET['url'];
$url = rtrim($url,"/");
$url = explode( "/",$url);

include "app/controllers/".$url[0].".php";

$ctlr = new $url[0]();
 
$ctlr->$url[1]($url[2]);










include "inc/footer.php"; 