<div class="search">
	<form action="" method="post">
		<input type="text" name="keyword" placeholder="Search here...">
		<select name="category" id="category">
			<?php 
				foreach ($cat as $key => $value) { 
			?>  
				<option value="<?php echo $value['id']; ?>"><?php echo $value['catName']; ?></option>
			<?php } ?>  
		</select>
		<button type="submit">Search</button>
	</form>
</div>