<?php 

class Index extends DController{
	public function __construct(){
		parent:: __construct();
	}

	public function home(){
		$this->load->view('home');  
	}
	public function category(){ 
		$table = "category";
		$data = array();
		$catmodel = $this->load->model('CatModel');
		$data['cat'] = $catmodel->catlist($table);  
		$this->load->view('category',$data); 
	}
	public function catById(){ 
		$table = "category";
		$id = 2;
		$data = array();
		$catmodel = $this->load->model('CatModel');
		$data['catbyid'] = $catmodel->catbyid($table, $id);  
		$this->load->view('catbyid',$data); 
	}
	public function addCategory(){
		$this->load->view('addcategory'); 
	}
	public function insertCategory(){
		$table = "category"; 
		$title = $_POST['title'];
		$catName = $_POST['catName'];
		$data = array(
			'title'=> $title,
			'catName'=> $catName 
			);
		$catmodel = $this->load->model('CatModel');
		$rslt = $catmodel->catInsert($table, $data); 
		if($rslt){
			$data['msg'] = "Successfully Added";
		}else{
			$data['msg'] = "Not Added";
		}
		$this->load->view('addcategory',$data);   
	}
}