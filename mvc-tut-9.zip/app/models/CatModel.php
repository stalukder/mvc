<?php 

class CatModel extends Dmodel{


	public function __construct(){
		parent::__construct();
	}

	public function catlist(){
		 $sql = "SELECT * FROM category";
		 $result = $this->db->query($sql);
		 return $result->fetchAll();
	}


}