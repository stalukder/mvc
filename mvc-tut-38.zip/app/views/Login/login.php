<div class="login">
	<form action="<?php echo BASE_URL; ?>/Login/loginAuth/" method="post">
		<table>
			<tr>
				<td>Username:</td>
				<td><input type="text" name="username"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="text" name="password"></td>
			</tr>
			<tr>
				<td> </td>
				<td><input type="submit" value="Login"></td>
			</tr>
		</table>
	</form>
</div>