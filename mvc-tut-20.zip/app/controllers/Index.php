<?php 

class Index extends DController{
	public function __construct(){
		parent:: __construct();
	}

	public function home(){
		$this->load->view('header');
 
		$table = "post";
		$data = array();
		$postModel = $this->load->model('PostModel');
		$data['apost'] = $postModel->allPost($table);  
		$this->load->view('content',$data);  
		$this->load->view('sidebar');  
		$this->load->view('footer');  
	} 
	public function postDetails(){ 
	 
	} 
}