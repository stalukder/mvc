	<div class="sidebar">
		<div class="singlesid">
			<h4>Category</h4>
			<a href="#" class="cat">Category</a>
			<a href="#" class="cat">Category</a>
			<a href="#" class="cat">Category</a>
			<a href="#" class="cat">Category</a>
			<a href="#" class="cat">Category</a>
		</div>
		<div class="singlesid">
			<h4>Latest Post</h4>
			<a href="#" class="cat">Single Post</a>
			<a href="#" class="cat">Single Post</a>
			<a href="#" class="cat">Single Post</a>
			<a href="#" class="cat">Single Post</a>
			<a href="#" class="cat">Single Post</a>
		</div>
	</div>
 

