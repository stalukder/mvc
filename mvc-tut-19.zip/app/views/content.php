
<div class="content">

 
	<div class="contenttex">
		<div class="post">
			<h2>Title ONe</h2>
			<div class="descrip">
				There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
				<a href="#" class="readmore">Read More</a>
			</div>
		</div>
		<div class="post">
			<h2>Title ONe</h2>
			<div class="descrip">
				There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
				<a href="#" class="readmore">Read More</a>
			</div>
		</div>
		<div class="post">
			<h2>Title ONe</h2>
			<div class="descrip">
				There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
				<a href="#" class="readmore">Read More</a>
			</div>
		</div>
		<div class="post">
			<h2>Title ONe</h2>
			<div class="descrip">
				There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
				<a href="#" class="readmore">Read More</a>
			</div>
		</div>
	</div>
