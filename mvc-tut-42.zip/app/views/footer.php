
</div>
  <footer class="footeroption">
	  <section class="footerone">
	  <p>Delowar Jahan Imran</p>
	  <p>Oracle Certified Professional,</p>
	  <p>Java SE 6 Programmer</p>
	  
	  </section>
	  <section class="footerone">
		  <p>Like us: facebook.com/ProDelowar</p>
		  <p>Join us: facebook.com/groups/PBPTBD</p>
		  <p>Web: www.trainingWithLiveProject.com</p>
	  </section>
  </footer>

</body>
</html>