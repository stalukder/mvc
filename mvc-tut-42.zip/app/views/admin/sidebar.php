		<td width="30%"> 
			<h4>Site Option</h4>
			<ul>
				<li><a href="<?php echo BASE_URL; ?>/Admin">Home</a></li> 
			</ul>  
			<ul>
				<li><a href="<?php echo BASE_URL; ?>/Admin">Login</a></li>
				<li><a href="<?php echo BASE_URL; ?>/Login/logout">Logout</a></li>
			</ul>  
			<h4>Category Option</h4>
			<ul>
				<li><a href="<?php echo BASE_URL; ?>/Admin/addcategory">Add CAtegory</a></li>
				<li><a href="<?php echo BASE_URL; ?>/Admin/category">Category</a></li>
			</ul> 
			<h4>Article Option</h4>
			<ul>
				<li><a href="<?php echo BASE_URL; ?>/Admin/addarticle">Add Article</a></li>
				<li><a href="<?php echo BASE_URL; ?>/Admin/article">Article List</a></li>
			</ul> 
		</td> 