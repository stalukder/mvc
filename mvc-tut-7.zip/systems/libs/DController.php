<?php 

class DController{
	protected $load = array();
	function __construct(){
		$this->load = new Load();
	}
}