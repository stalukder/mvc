<?php 

class CatModel{
	public function __construct(){
		echo "Category Model...";
	}

	public function catlist(){
		$array = array(
			'catOne' => 'College',
			'catTwo' => 'School',
			'catThree' => 'Hospital'
			);
		return $array;
	}


}