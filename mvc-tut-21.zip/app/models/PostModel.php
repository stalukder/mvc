<?php 

class PostModel extends Dmodel{


	public function __construct(){
		parent::__construct();
	}

	public function allPost($table){
		$sql = "SELECT * FROM $table ORDER BY ID DESC LIMIT 3 ";
		return $this->db->select($sql);
	}  
}