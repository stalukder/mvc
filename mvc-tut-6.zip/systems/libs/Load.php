<?php 

class Load{
	public function __construct(){

	}

	public function view($fnm){
		include "app/views/".$fnm.".php"; 
	}
}