<?php 

class CatModel extends Dmodel{


	public function __construct(){
		parent::__construct();
	}

	public function catlist(){
		$table = "category";
		return $this->db->select($table);
	}


}