<?php 

class Database extends PDO{

	
	public function __construct(){
		$dsn = "mysql:host=localhost;dbname=mvc";
		$username = "root";
		$password = ""; 
		parent::__construct($dsn,$username,$password);
	}

	public function select($table){ 
		$sql = "SELECT * FROM $table";
		$result = $this->prepare($sql);
		$result->execute();
		return $result->fetchAll();
	}
  

}